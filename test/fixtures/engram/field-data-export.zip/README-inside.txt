Field Notebook — export bundle (test fixture)

This .zip exists only to exercise the unsupported-file placeholder
(manual test plan, case F8). BrainFrame is a note reader / e-reader:
an archive is a container, not a document, so it will never render
inline — unlike PDF/EPUB, which are deferred and will get real viewers.
Nothing in the app reads this; you are meant to see the 'can't display
this format' message, not these bytes.
